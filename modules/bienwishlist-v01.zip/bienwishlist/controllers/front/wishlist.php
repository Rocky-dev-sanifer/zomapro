<?php
/**
 * Page /mes-favoris — accessible uniquement aux clients connectés.
 * Liste les biens favoris du client avec lien vers le détail et bouton de retrait.
 */

require_once _PS_MODULE_DIR_ . 'bienwishlist/classes/WishlistManager.php';
require_once _PS_MODULE_DIR_ . 'realestatemanager/classes/RealEstateProperty.php';

class BienWishlistWishlistModuleFrontController extends ModuleFrontController
{
    public $auth = true;
    public $authRedirection = 'module-bienwishlist-wishlist';
    public $ssl = true;

    public function setMedia()
    {
        parent::setMedia();
        // CSS et JS déjà enregistrés via le hook actionFrontControllerSetMedia
    }

    public function initContent()
    {
        parent::initContent();

        $id_customer = (int)$this->context->customer->id;
        $rows = WishlistManager::getWishlistWithDetails($id_customer);

        $types = RealestateManager::getPropertyTypes();
        $properties = [];

        foreach ($rows as $row) {
            $cover = WishlistManager::getCoverImage((int)$row['id_property']);
            $cover_url = $cover
                ? _PS_BASE_URL_ . _MODULE_DIR_ . 'gestionbien/upload/' . $cover
                : '';
            $type_key = isset($row['type']) ? $row['type'] : '';
            $type_label = isset($types[$type_key]) ? $types[$type_key] : ucfirst((string)$type_key);

            $properties[] = [
                'id_property' => (int)$row['id_property'],
                'title'       => $row['title'],
                'type'        => $type_key,
                'type_label'  => $type_label,
                'region'      => $row['region'],
                'surface'     => (int)$row['surface'],
                'price'       => (float)$row['price'],
                'furnished'   => (int)$row['furnished'],
                'bedrooms'    => (int)$row['bedrooms'],
                'toilets'     => (int)$row['toilets'],
                'parking'     => (int)$row['parking'],
                'cover'       => $cover_url,
                'detail_url'  => $this->context->link->getModuleLink('gestionbien', 'detail', ['id' => (int)$row['id_property']]),
            ];
        }

        $this->context->smarty->assign([
            'properties'       => $properties,
            'count'            => count($properties),
            'list_url'         => $this->context->link->getModuleLink('gestionbien', 'list'),
            'ajax_url'         => $this->context->link->getModuleLink('bienwishlist', 'ajax', [], true),
            'customer_name'    => $this->context->customer->firstname,
        ]);

        $this->setTemplate('module:bienwishlist/views/templates/front/wishlist.tpl');
    }
}
