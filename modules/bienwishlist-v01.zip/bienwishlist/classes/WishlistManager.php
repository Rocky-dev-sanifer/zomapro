<?php
/**
 * Modèle BienWishlist - gère la table real_estate_wishlist
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class WishlistManager
{
    /**
     * Vérifie si un bien est dans la wishlist du client
     */
    public static function exists($id_customer, $id_property)
    {
        $id_customer = (int)$id_customer;
        $id_property = (int)$id_property;
        if ($id_customer <= 0 || $id_property <= 0) {
            return false;
        }
        $sql = 'SELECT id_wishlist FROM `' . _DB_PREFIX_ . 'real_estate_wishlist`
                WHERE id_customer = ' . $id_customer . '
                AND id_property = ' . $id_property;
        return (bool)Db::getInstance()->getValue($sql);
    }

    /**
     * Ajoute un bien à la wishlist (idempotent grâce à l'index unique)
     * Retourne true si insertion ou déjà présent.
     */
    public static function add($id_customer, $id_property)
    {
        $id_customer = (int)$id_customer;
        $id_property = (int)$id_property;
        if ($id_customer <= 0 || $id_property <= 0) {
            return false;
        }

        // Vérifier que le bien existe et est actif
        if (!self::propertyIsActive($id_property)) {
            return false;
        }

        if (self::exists($id_customer, $id_property)) {
            return true;
        }

        return (bool)Db::getInstance()->insert('real_estate_wishlist', [
            'id_customer' => $id_customer,
            'id_property' => $id_property,
            'date_add'    => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Retire un bien de la wishlist
     */
    public static function remove($id_customer, $id_property)
    {
        $id_customer = (int)$id_customer;
        $id_property = (int)$id_property;
        if ($id_customer <= 0 || $id_property <= 0) {
            return false;
        }
        return (bool)Db::getInstance()->delete(
            'real_estate_wishlist',
            'id_customer = ' . $id_customer . ' AND id_property = ' . $id_property
        );
    }

    /**
     * Bascule l'état (ajoute si absent, retire si présent).
     * Retourne ['success' => bool, 'in_wishlist' => bool]
     */
    public static function toggle($id_customer, $id_property)
    {
        if (self::exists($id_customer, $id_property)) {
            $ok = self::remove($id_customer, $id_property);
            return ['success' => $ok, 'in_wishlist' => false];
        }
        $ok = self::add($id_customer, $id_property);
        return ['success' => $ok, 'in_wishlist' => $ok];
    }

    /**
     * Compte le nombre d'éléments dans la wishlist du client (uniquement biens actifs)
     */
    public static function countByCustomer($id_customer)
    {
        $id_customer = (int)$id_customer;
        if ($id_customer <= 0) {
            return 0;
        }
        $sql = 'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'real_estate_wishlist` w
                INNER JOIN `' . _DB_PREFIX_ . 'real_estate_property` p ON p.id_property = w.id_property
                WHERE w.id_customer = ' . $id_customer . '
                AND p.active = 1';
        return (int)Db::getInstance()->getValue($sql);
    }

    /**
     * Liste des IDs de biens dans la wishlist du client (utile pour JS)
     * Ne retourne que les biens actifs.
     */
    public static function getPropertyIdsForCustomer($id_customer)
    {
        $id_customer = (int)$id_customer;
        if ($id_customer <= 0) {
            return [];
        }
        $sql = 'SELECT w.id_property FROM `' . _DB_PREFIX_ . 'real_estate_wishlist` w
                INNER JOIN `' . _DB_PREFIX_ . 'real_estate_property` p ON p.id_property = w.id_property
                WHERE w.id_customer = ' . $id_customer . '
                AND p.active = 1';
        $rows = Db::getInstance()->executeS($sql);
        if (!$rows) {
            return [];
        }
        return array_map('intval', array_column($rows, 'id_property'));
    }

    /**
     * Liste complète des biens dans la wishlist du client, avec données.
     * Renvoie un tableau de tableaux associatifs prêts pour l'affichage.
     */
    public static function getWishlistWithDetails($id_customer)
    {
        $id_customer = (int)$id_customer;
        if ($id_customer <= 0) {
            return [];
        }
        $sql = 'SELECT p.*, w.date_add AS date_added_wishlist
                FROM `' . _DB_PREFIX_ . 'real_estate_wishlist` w
                INNER JOIN `' . _DB_PREFIX_ . 'real_estate_property` p ON p.id_property = w.id_property
                WHERE w.id_customer = ' . $id_customer . '
                AND p.active = 1
                ORDER BY w.date_add DESC';
        $rows = Db::getInstance()->executeS($sql);
        return $rows ? $rows : [];
    }

    /**
     * Vérifie qu'un bien existe et est actif (sécurité)
     */
    protected static function propertyIsActive($id_property)
    {
        $id_property = (int)$id_property;
        $sql = 'SELECT id_property FROM `' . _DB_PREFIX_ . 'real_estate_property`
                WHERE id_property = ' . $id_property . ' AND active = 1';
        return (bool)Db::getInstance()->getValue($sql);
    }

    /**
     * Récupère l'image de couverture d'un bien
     */
    public static function getCoverImage($id_property)
    {
        $id_property = (int)$id_property;
        $sql = 'SELECT image_path FROM `' . _DB_PREFIX_ . 'real_estate_property_image`
                WHERE id_property = ' . $id_property . '
                ORDER BY is_cover DESC, position ASC
                LIMIT 1';
        return Db::getInstance()->getValue($sql);
    }
}
