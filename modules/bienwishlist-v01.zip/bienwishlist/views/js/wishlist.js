/* =================================================================
   BienWishlist — JS frontend
   - Injecte un bouton cœur sur chaque card de bien et sur la page détail
   - Si l'utilisateur n'est PAS connecté : affiche une modale qui redirige
     vers la page de connexion (avec retour à la page courante)
   - Si l'utilisateur est connecté : toggle AJAX sans rechargement
   ================================================================= */
(function () {
    'use strict';

    var cfg = window.BW_CONFIG || {};
    cfg.texts = cfg.texts || {};

    // Set des IDs en wishlist (référence vivante)
    var wishlistIds = new Set((cfg.wishlistIds || []).map(function (n) { return parseInt(n, 10); }));

    var BW = {
        // ---------- Utilitaires --------------------------------------
       /* extractIdFromUrl: function (url) {
            if (!url) return null;
            var m = url.match(/\/bien\/(\d+)/);
            if (m) return parseInt(m[1], 10);
            m = url.match(/[?&]id=(\d+)/);
            if (m) return parseInt(m[1], 10);
            return null;
        },*/
        extractIdFromUrl: function (url) {
            if (!url) return null;

            var patterns = [
                /\/bien\/(\d+)/,
                /\/biens-immobiliers\/(\d+)/,
                /[?&]id=(\d+)/
            ];

            for (var i = 0; i < patterns.length; i++) {
                var m = url.match(patterns[i]);
                if (m) return parseInt(m[1], 10);
            }

            return null;
        },

        // ---------- Toast --------------------------------------------
        showToast: function (msg, isError) {
            var t = document.querySelector('.bw-toast');
            if (!t) {
                t = document.createElement('div');
                t.className = 'bw-toast';
                t.innerHTML = '<i class="material-icons">favorite</i><span class="bw-toast-text"></span>';
                document.body.appendChild(t);
            }
            t.classList.toggle('bw-error', !!isError);
            t.querySelector('.material-icons').textContent = isError ? 'error_outline' : 'favorite';
            t.querySelector('.bw-toast-text').textContent = msg;
            t.classList.add('bw-show');
            clearTimeout(t._timer);
            t._timer = setTimeout(function () { t.classList.remove('bw-show'); }, 2500);
        },

        // ---------- Modale Login -------------------------------------
        showLoginModal: function () {
            var existing = document.querySelector('.bw-login-modal');
            if (existing) {
                existing.classList.add('bw-show');
                return;
            }
            var back = encodeURIComponent(window.location.href);
            var loginHref = cfg.loginUrl + (cfg.loginUrl.indexOf('?') > -1 ? '&' : '?') + 'back=' + back;

            var modal = document.createElement('div');
            modal.className = 'bw-login-modal';
            modal.innerHTML =
                '<div class="bw-login-modal-content">' +
                    '<div class="bw-login-modal-icon"><i class="material-icons">favorite</i></div>' +
                    '<h3>' + (cfg.texts.loginMsg || 'Connectez-vous pour ajouter ce bien à vos favoris') + '</h3>' +
                    '<p>Créez un compte ou connectez-vous pour sauvegarder vos biens préférés et les retrouver à tout moment.</p>' +
                    '<div class="bw-login-modal-actions">' +
                        '<button type="button" class="bw-btn-ghost bw-modal-close">Annuler</button>' +
                        '<a href="' + loginHref + '" class="bw-btn-primary"><i class="material-icons">login</i> Se connecter</a>' +
                    '</div>' +
                '</div>';
            document.body.appendChild(modal);

            requestAnimationFrame(function () { modal.classList.add('bw-show'); });

            var close = function () {
                modal.classList.remove('bw-show');
                setTimeout(function () { if (modal.parentNode) modal.parentNode.removeChild(modal); }, 220);
            };
            modal.querySelector('.bw-modal-close').addEventListener('click', close);
            modal.addEventListener('click', function (e) { if (e.target === modal) close(); });
            document.addEventListener('keydown', function esc(e) {
                if (e.key === 'Escape') { close(); document.removeEventListener('keydown', esc); }
            });
        },

        // ---------- Mise à jour visuelle d'un bouton -----------------
        setButtonState: function (btn, inList) {
            btn.classList.toggle('bw-active', inList);
            var icon = btn.querySelector('.material-icons');
            if (icon) icon.textContent = inList ? 'favorite' : 'favorite_border';
            var label = inList ? (cfg.texts.remove || 'Retirer des favoris') : (cfg.texts.add || 'Ajouter aux favoris');
            btn.setAttribute('aria-label', label);
            btn.setAttribute('title', label);
            // Pour le bouton détail qui affiche du texte
            var labelEl = btn.querySelector('.bw-btn-label');
            if (labelEl) {
                labelEl.textContent = inList ? (cfg.texts.inList || 'Dans vos favoris') : (cfg.texts.add || 'Ajouter aux favoris');
            }
        },

        // ---------- Toggle AJAX --------------------------------------
        toggle: function (btn, id) {
            // Sécurité : si pas connecté, on déclenche la modale de login
            if (!cfg.isLogged) {
                BW.showLoginModal();
                return;
            }

            btn.disabled = true;
            var fd = new FormData();
            fd.append('action', 'toggle');
            fd.append('id_property', id);

            fetch(cfg.ajaxUrl, {
                method: 'POST',
                body: fd,
                credentials: 'same-origin',
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(function (r) {
                if (r.status === 401) {
                    // Session expirée pendant la navigation
                    return r.json().then(function (j) {
                        BW.showLoginModal();
                        throw new Error('require_login');
                    });
                }
                return r.json();
            })
            .then(function (data) {
                btn.disabled = false;
                if (!data.success) {
                    BW.showToast(data.message || cfg.texts.error || 'Erreur', true);
                    return;
                }
                var nowIn = !!data.in_wishlist;
                // Mettre à jour tous les boutons pour ce bien (card + détail)
                document.querySelectorAll('[data-bw-id="' + id + '"]').forEach(function (b) {
                    BW.setButtonState(b, nowIn);
                });
                if (nowIn) wishlistIds.add(id); else wishlistIds.delete(id);
                BW.showToast(data.message || (nowIn ? cfg.texts.added : cfg.texts.removed));

                // Sur la page wishlist, retirer la card visuellement
                if (!nowIn && window.BW_PAGE && window.BW_PAGE.isWishlistPage) {
                    var card = document.querySelector('[data-bw-card="' + id + '"]');
                    if (card) {
                        card.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                        card.style.opacity = '0';
                        card.style.transform = 'scale(0.92)';
                        setTimeout(function () {
                            if (card.parentNode) card.parentNode.removeChild(card);
                            BW.refreshWishlistPageEmpty();
                        }, 320);
                    }
                }
            })
            .catch(function (e) {
                btn.disabled = false;
                if (e && e.message === 'require_login') return;
                BW.showToast(cfg.texts.error || 'Erreur de connexion', true);
            });
        },

        refreshWishlistPageEmpty: function () {
            var grid = document.querySelector('.bw-grid');
            if (!grid) return;
            if (grid.children.length === 0) {
                // Recharger pour afficher l'état vide proprement
                window.location.reload();
            } else {
                // Mettre à jour le compteur
                var sub = document.querySelector('.bw-page-sub');
                var count = grid.children.length;
                if (sub) {
                    sub.textContent = count + ' ' + (count > 1 ? 'biens enregistrés' : 'bien enregistré');
                }
            }
        },

        // ---------- Construction d'un bouton coeur (overlay card) ----
        buildCardButton: function (id) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'bw-heart-btn bw-on-card';
            btn.setAttribute('data-bw-id', id);
            btn.innerHTML = '<i class="material-icons">favorite_border</i>';
            BW.setButtonState(btn, wishlistIds.has(id));
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                BW.toggle(btn, id);
            });
            return btn;
        },

        // ---------- Injection sur cards listing ----------------------
        scanCards: function (root) {
            (root || document).querySelectorAll('.gb-card-result').forEach(function (card) {
                if (card.querySelector('.bw-heart-btn')) return; // déjà injecté

                // Trouver l'ID via le lien détail
                var link = card.querySelector('a.gb-card-img-link') || card.querySelector('a[href*="biens-immobiliers"]');
                if (!link) return;
                var id = BW.extractIdFromUrl(link.getAttribute('href'));
                if (!id) return;

                var imgDiv = card.querySelector('.gb-card-img');
                var host = imgDiv || card;
                if (!imgDiv) host.style.position = 'relative';
                host.appendChild(BW.buildCardButton(id));
            });
        },

        // ---------- Injection sur la page détail ---------------------
        injectOnDetail: function () {
            // Si on n'est pas sur la page détail, sortir
            var detailTags = document.querySelector('.gb-detail-tags');
            var detailInfo = document.querySelector('.gb-detail-info');
            if (!detailTags && !detailInfo) return;

            var id = BW.extractIdFromUrl(window.location.href)
                  || BW.extractIdFromUrl((document.querySelector('a.gb-back-link') || {}).getAttribute && (document.querySelector('a.gb-back-link') || {}).href);
            // Fallback : lire l'ID depuis un éventuel meta ou attribut
            if (!id) {
                var ds = document.querySelector('[data-property-id]');
                if (ds) id = parseInt(ds.getAttribute('data-property-id'), 10);
            }
            if (!id) {
                // Dernier recours : pas d'ID identifiable
                return;
            }

            // Si bouton déjà présent, ne pas dupliquer
            if (document.querySelector('.bw-heart-btn-detail[data-bw-id="' + id + '"]')) return;

            // Construire le bouton détail (large, avec libellé)
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'bw-heart-btn-detail';
            btn.setAttribute('data-bw-id', id);
            var inList = wishlistIds.has(id);
            btn.innerHTML =
                '<i class="material-icons">' + (inList ? 'favorite' : 'favorite_border') + '</i>' +
                '<span class="bw-btn-label">' + (inList ? (cfg.texts.inList || 'Dans vos favoris') : (cfg.texts.add || 'Ajouter aux favoris')) + '</span>';
            if (inList) btn.classList.add('bw-active');
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                BW.toggle(btn, id);
            });

            // Insérer juste après les tags si présents, sinon en haut de l'info
            if (detailTags && detailTags.parentNode) {
                detailTags.parentNode.insertBefore(btn, detailTags.nextSibling);
            } else if (detailInfo) {
                detailInfo.insertBefore(btn, detailInfo.firstChild);
            }

            // Ajouter aussi une icône en overlay sur la galerie principale (optionnel)
            var galleryMain = document.querySelector('.gb-gallery-main');
            if (galleryMain && !galleryMain.querySelector('.bw-heart-btn')) {
                galleryMain.style.position = galleryMain.style.position || 'relative';
                galleryMain.appendChild(BW.buildCardButton(id));
            }
        },

        // ---------- Hook sur les boutons déjà présents (page wishlist)
        bindExistingButtons: function () {
            document.querySelectorAll('.bw-heart-btn[data-bw-id]:not([data-bw-bound])').forEach(function (btn) {
                btn.setAttribute('data-bw-bound', '1');
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var id = parseInt(btn.getAttribute('data-bw-id'), 10);
                    if (id) BW.toggle(btn, id);
                });
            });
        },

        // ---------- Observer pour le re-rendu AJAX (recherche) -------
        observe: function () {
            var grid = document.getElementById('gb-results-grid');
            if (!grid) return;
            var obs = new MutationObserver(function () {
                BW.scanCards(grid);
            });
            obs.observe(grid, { childList: true, subtree: true });
        },

        // ---------- Init ---------------------------------------------
        init: function () {
            BW.scanCards(document);
            BW.injectOnDetail();
            BW.bindExistingButtons();
            BW.observe();
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', BW.init);
    } else {
        BW.init();
    }

    // Exposer pour debug éventuel
    window.BW = BW;
})();
