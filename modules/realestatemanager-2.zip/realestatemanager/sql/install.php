<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

$sql = [];

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'realestate_property` (
    `id_property` INT(11) NOT NULL AUTO_INCREMENT,
    `id_customer` INT(11) NOT NULL,
    `id_shop` INT(11) NOT NULL DEFAULT 1,
    `type` VARCHAR(50) NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `surface` DECIMAL(10,2) DEFAULT 0,
    `region` VARCHAR(100) DEFAULT NULL,
    `price` DECIMAL(15,2) DEFAULT 0,
    `price_per_m2` TINYINT(1) DEFAULT 0,
    `furnished` TINYINT(1) DEFAULT 0,
    `description` TEXT,
    `bedrooms` INT(11) DEFAULT 0,
    `toilets` INT(11) DEFAULT 0,
    `parkings` INT(11) DEFAULT 0,
    `titre_foncier` TINYINT(1) DEFAULT 0,
    `borne` TINYINT(1) DEFAULT 0,
    `premier_plan` TINYINT(1) DEFAULT 0,
    `quartier_residentiel` TINYINT(1) DEFAULT 0,
    `google_earth_link` VARCHAR(500) DEFAULT NULL,
    `video` VARCHAR(255) DEFAULT NULL,
    `status` VARCHAR(50) DEFAULT "available",
    `active` TINYINT(1) DEFAULT 1,
    `date_add` DATETIME NOT NULL,
    `date_upd` DATETIME NOT NULL,
    PRIMARY KEY (`id_property`),
    KEY `idx_customer` (`id_customer`),
    KEY `idx_type` (`type`),
    KEY `idx_active` (`active`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'realestate_feature` (
    `id_feature` INT(11) NOT NULL AUTO_INCREMENT,
    `id_property` INT(11) NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id_feature`),
    KEY `idx_property` (`id_property`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'realestate_image` (
    `id_image` INT(11) NOT NULL AUTO_INCREMENT,
    `id_property` INT(11) NOT NULL,
    `filename` VARCHAR(255) NOT NULL,
    `position` INT(11) DEFAULT 0,
    PRIMARY KEY (`id_image`),
    KEY `idx_property` (`id_property`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

foreach ($sql as $query) {
    if (!Db::getInstance()->execute($query)) {
        return false;
    }
}

// Valeurs par défaut
Configuration::updateValue('REALESTATE_PER_PAGE', 12);
Configuration::updateValue('REALESTATE_CURRENCY', 'Ar');
