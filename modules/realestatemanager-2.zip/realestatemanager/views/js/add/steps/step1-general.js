/**
 * Étape 1 — Informations générales.
 *
 * Interface implémentée par tous les modules d'étape :
 *   - init(ctx)   : initialisation, écouteurs DOM
 *   - collect()   : renvoie les champs à envoyer au serveur (objet plat)
 *   - validate()  : renvoie { ok: bool, message?: string }
 */
(function (global) {
    'use strict';

    var UI = global.RealEstateUI;

    var Step1 = {
        step: 1,
        $panel: null,

        init: function (ctx) {
            this.$panel = document.querySelector('.re-step-panel[data-panel="1"]');
            if (!this.$panel) return;

            UI.bindToggleLabel('re-price-per-m2', 're-price-per-m2-lbl');
            UI.bindToggleLabel('re-furnished', 're-furnished-lbl');
            UI.bindCharCounter('re-description', 're-desc-count');
        },

        collect: function () {
            return {
                type: this._val('type'),
                title: this._val('title'),
                surface: this._val('surface'),
                region: this._val('region'),
                price: this._val('price'),
                price_per_m2: this._checked('re-price-per-m2'),
                furnished: this._checked('re-furnished'),
                description: this._val('description')
            };
        },

        validate: function () {
            var data = this.collect();
            if (!data.type) {
                return { ok: false, message: 'Le type de bien est obligatoire.' };
            }
            var price = parseFloat(data.price);
            if (!price || price <= 0) {
                return { ok: false, message: 'Le prix doit être supérieur à 0.' };
            }
            if (data.surface !== '' && parseFloat(data.surface) < 0) {
                return { ok: false, message: 'La surface ne peut pas être négative.' };
            }
            if (data.description && data.description.length > 500) {
                return { ok: false, message: 'La description ne peut pas dépasser 500 caractères.' };
            }
            return { ok: true };
        },

        _val: function (name) {
            var el = this.$panel.querySelector('[name="' + name + '"]');
            return el ? el.value : '';
        },

        _checked: function (id) {
            var el = document.getElementById(id);
            return el && el.checked ? 1 : 0;
        }
    };

    global.RealEstateSteps = global.RealEstateSteps || {};
    global.RealEstateSteps.step1 = Step1;
})(window);
